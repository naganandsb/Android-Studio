package com.example.birthdaywishsms;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public class AlramHandler {
    private Context context;

    public AlramHandler(Context context) {
        this.context = context;
    }

    public  void setAlarmManager()
    {
        Intent intent =new Intent(context,ExecuteService.class);
        PendingIntent sender = PendingIntent.getBroadcast(context,2,intent,0);
        AlarmManager am =(AlarmManager)context.getSystemService(context.ALARM_SERVICE);
        if(am!=null)
        {
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP,0,60000,sender);
        }


    }
    public  void cancelAlarmManager()
    {
        Intent intent =new Intent(context,ExecuteService.class);
        PendingIntent sender = PendingIntent.getBroadcast(context,2,intent,0);
        AlarmManager am =(AlarmManager)context.getSystemService(context.ALARM_SERVICE);
        if(am!=null)
        {
            am.cancel(sender);
        }
    }
}
