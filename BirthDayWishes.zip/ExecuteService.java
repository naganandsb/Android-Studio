package com.example.birthdaywishsms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Calendar;

public class ExecuteService extends BroadcastReceiver {

    File VideoDir,ImgDir;
    @Override
    public void onReceive(Context context, Intent intent) {

        ReadFile();

//        VideoDir = new File("/sdcard/NagVideoFold/");
//        ImgDir = new File("/sdcard/NagImgFold");
//        if(!VideoDir.exists())
//        {
//            VideoDir.mkdirs();
//            ImgDir.mkdirs();
//        }
//
//        Moveing(context);
    }

    public  void ReadFile()
    {
        Calendar cal = Calendar.getInstance();
        int time_h= cal.get(Calendar.HOUR_OF_DAY);
        int time_min = cal.get(Calendar.MINUTE);

        int today_date = cal.get(Calendar.DATE);
        int today_month = cal.get(Calendar.MONTH) +1;
        if(time_h==0 && time_min==0)
        {
            File savepath = new File("/sdcard/BirthdayFile/Birthdaydata.txt");
            if(savepath.exists()==true)
            {
                try {
                    FileInputStream fi = new FileInputStream("/sdcard/BirthdayFile/Birthdaydata.txt");

                    InputStreamReader isr = new InputStreamReader(fi);

                    BufferedReader bf =new BufferedReader(isr);

                    String line;
                    while((line =bf.readLine() )!=null)
                    {
                        String[] linesplt = line.split(" ");
                        String[] datesplt = linesplt[1].split("/");

                        if(today_date==Integer.parseInt(datesplt[1] ) && today_month==Integer.parseInt(datesplt[0]))
                        {
                            SendSMS(linesplt[0],linesplt[2]);
                        }

                    }

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    public void SendSMS(String Name,String number)
    {
        SmsManager sms =SmsManager.getDefault();
        sms.sendTextMessage(number,null,"Many many Happy Returns of the day "+Name,null,null);

    }

    public void Moveing(Context context)
    {
        File StatusDir = new File("/sdcard/WhatsApp/Media/.Statuses/");
        if(!StatusDir.exists())
        {
            Toast.makeText(context, "Status Folder not found", Toast.LENGTH_SHORT).show();
            return;
        }
        File[] filenames = StatusDir.listFiles();
        for(int i=0;i< filenames.length;i++)
        {
            String fname = filenames[i].toString();

            if(fname.endsWith(".jpg"))
            {
                String[] fname2 = fname.split("/");
                String fname3 = fname2[fname2.length-1];
                copyFile(fname,ImgDir.getPath()+"/"+fname3);
                filenames[i].delete();
            }
            else if(fname.endsWith(".mp4"))
            {
                String[] fname2 = fname.split("/");
                String fname3 = fname2[fname2.length-1];
                copyFile(fname,VideoDir.getPath()+"/"+fname3);
                filenames[i].delete();
            }

        }

    }

    public static void copyFile(String inputPath, String outputPath) {

        InputStream in = null;
        OutputStream out = null;
        try {
            in = new FileInputStream(inputPath);
            out = new FileOutputStream(outputPath);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;

            // write the output file (You have now copied the file)
            out.flush();
            out.close();
            out = null;


        } catch (FileNotFoundException fnfe1) {
            //do nothing
        } catch (Exception e) {
            //do nothing
        }
    }

}
