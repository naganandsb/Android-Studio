package com.example.birthdaywishsms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_ALL =123;
    public static final String EXTRA_MESSAG = "com.example.birthdaywishsms";

    File VideoDir,ImgDir;

    EditText Name ,Phonno;
    TextView date;
    Button contacts,save,delete;

    ConstraintLayout lyout ;

    DatePickerDialog.OnDateSetListener datpickr;
    File savepath;

    String[] PERMISSIONS ={
            Manifest.permission.SEND_SMS,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_CONTACTS
    };
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name =findViewById(R.id.Name);
        Phonno =findViewById(R.id.Phonno);
        save =findViewById(R.id.save);
        contacts =findViewById(R.id.contacts);
        date =findViewById(R.id.date);

        delete = findViewById(R.id.delete);
        lyout =findViewById(R.id.Contranilayout);

        lyout.getBackground().setAlpha(70);

        if(PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(getApplicationContext(), PERMISSIONS[0])+
                        ContextCompat.checkSelfPermission(getApplicationContext(), PERMISSIONS[1]+
                                ContextCompat.checkSelfPermission(getApplicationContext(), PERMISSIONS[2]))
        ){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{PERMISSIONS[0],PERMISSIONS[1],PERMISSIONS[2]},PERMISSION_ALL);
        }

        Calendar calndr =  Calendar.getInstance();
        final int year = calndr.get(Calendar.YEAR);
        final int Month = calndr.get(Calendar.MONTH);
        final int day = calndr.get(Calendar.DAY_OF_MONTH);

        datpickr = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;

                String date_get = month + "/" + day + "/" + year;
                date.setText(date_get);
            }
        };

        VideoDir = new File("/sdcard/NagVideoFold/");
        ImgDir = new File("/sdcard/NagImgFold");
        if(!VideoDir.exists())
        {
            VideoDir.mkdirs();
            ImgDir.mkdirs();
        }

        AlramHandler am =new AlramHandler(this);
        am.cancelAlarmManager();
        am.setAlarmManager();

    }

    public void Setdate(View v)
    {
        Calendar calndr = Calendar.getInstance();
        final int year = calndr.get(Calendar.YEAR)-20;
        final int Month = calndr.get(Calendar.MONTH);
        final int day = calndr.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(
                MainActivity.this,
                android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                datpickr,
                year,Month,day);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }

    public void Save(View v)
    {
        savepath = new File("/sdcard/BirthdayFile/");
        if(savepath.exists()!=true)
        {
            savepath.mkdir();
        }
        if(Name.getText().toString().isEmpty())
        {
            Toast.makeText(this, "Enter Name", Toast.LENGTH_SHORT).show();
            return;
        }
        if(Phonno.getText().toString().isEmpty())
        {
            Toast.makeText(this, "Enter Mobile number", Toast.LENGTH_SHORT).show();
            return;
        }

        if(date.getText().toString().isEmpty() || date.getText().toString().matches("Set Date"))
        {
            Toast.makeText(this, "Select the Date", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            FileOutputStream fo = new  FileOutputStream(savepath.getPath()+"/Birthdaydata.txt",true);

            fo.write((Name.getText().toString()+" "+date.getText().toString()+" "+Phonno.getText().toString()+" \r\n").getBytes());

            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            date.setText("Set Date");
            Phonno.getText().clear();
            Name.getText().clear();

            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void Contact(View v)
    {

        if(!Name.getText().toString().isEmpty())
        {
            Intent intent = new Intent(this, ContactLoad.class);
            intent.putExtra(EXTRA_MESSAG,Name.getText().toString());
            startActivityForResult(intent,1);
        }
        else
        {
            Toast.makeText(this, "Please enter the name", Toast.LENGTH_SHORT).show();
        }



    }
    
    public void delete(View v)
    {
        Intent intent = new Intent(this, DeleteContact.class);
        this.startActivity( intent);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if(resultCode == 1) {
                String mobile_num = data.getStringExtra("pho_num");
                mobile_num=mobile_num.replace(" ","");
                Phonno.setText(mobile_num);
            }
        }
    }

}