package com.example.birthdaywishsms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ContactLoad extends AppCompatActivity {

    ListView contactdisp;
    TextView name_label;
    ArrayList<String> contacts_name;
    ArrayList<String> contacts_num;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_load);

        contactdisp = findViewById(R.id.listview);
        name_label = findViewById(R.id.label_search);



        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAG);
        name_label.setText(message.toUpperCase());
        name_label.setTextColor(Color.RED);

        showcontacts();

        final ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,contacts_name);
        contactdisp.setAdapter(adapter);

        contactdisp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.putExtra("pho_num",contacts_num.get(position) );
                setResult(1, intent);
                finish();
            }
        });
    }

    public void showcontacts()
    {
        c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,null,null
                ,ContactsContract.Contacts.DISPLAY_NAME+" ASC ");

        String search= name_label.getText().toString();

        contacts_name =new ArrayList<String>();
        contacts_num =new ArrayList<String>();
        while(c.moveToNext())
        {
            String tempname = c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));



            if ( tempname.toLowerCase().indexOf(search.toLowerCase()) != -1 )
            {
                contacts_name.add(tempname);
                contacts_num.add(c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)));
            }

        }
        if(contacts_name.isEmpty())
        {
            contacts_name.add("NO RESULT FOUND FOR: "+search);
        }
        c.close();

    }
}