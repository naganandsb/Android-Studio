package com.example.birthdaywishsms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;

public class DeleteContact extends AppCompatActivity {

    ListView contactdisp;
    int position_got;
    ArrayList<String> Display_list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_contact);

        contactdisp = findViewById(R.id.listview);

        ReadFile();
        final ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,Display_list);
        contactdisp.setAdapter(adapter);


        contactdisp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                position_got=position;
                Save();
                finish();

            }
        });


    }

    public  void ReadFile()
    {
        Display_list= new ArrayList<String>();
        File savepath = new File("/sdcard/BirthdayFile/Birthdaydata.txt");
        if(savepath.exists()==true)
        {
            try {
                FileInputStream fi = new FileInputStream("/sdcard/BirthdayFile/Birthdaydata.txt");

                InputStreamReader isr = new InputStreamReader(fi);

                BufferedReader bf =new BufferedReader(isr);

                String line;
                while((line =bf.readLine() )!=null)
                {
                    Display_list.add(line);
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        else
        {
            Display_list.add("No data is present");
        }

    }

    public void Save()
    {
        int loop_count=0;
        File savepath = new File("/sdcard/BirthdayFile/");
        if(savepath.exists()!=true)
        {
            savepath.mkdir();
        }
        try {
            FileOutputStream fo = new  FileOutputStream(savepath.getPath()+"/Birthdaydata.txt",false);

            for (String name:Display_list
                 ) {

                if(position_got == loop_count)
                {
                    continue;
                }
                loop_count++;
                fo.write((name+" \r\n").getBytes());
            }



            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}