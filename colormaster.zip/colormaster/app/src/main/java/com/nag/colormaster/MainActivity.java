package com.nag.colormaster;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText  et;
    ConstraintLayout clt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et = (EditText) findViewById(R.id.editTextTextPersonName);
        clt = (ConstraintLayout) findViewById(R.id.contrainlayout1);
    }

    public void print(View v)
    {
        int a,b,c,d;
        String value = et.getText().toString();
        a = Integer.parseInt(value.split(",")[0]);
        b = Integer.parseInt(value.split(",")[1]);
        c = Integer.parseInt(value.split(",")[2]);
        d = Integer.parseInt(value.split(",")[3]);

        clt.setBackgroundColor(Color.argb(a,b,c,d));
    }
}