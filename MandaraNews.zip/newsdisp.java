package com.nag.mandarnews;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class newsdisp extends AppCompatActivity {
    TextView tv_news;
    TextView tv_love;
    TextView tv_like;
    TextView tv_dislike;
    ImageView iv_news;
    ImageView iv_love;
    ImageView iv_like;
    ImageView iv_dislike;
    TextView tv_title;
    String title;
    int like_flag = 0;
    int dislike_flag = 0;
    int heart_flag = 0;
    DatabaseReference myRef;
    long love_val;
    long like_val;
    long dislike_val;
    HashMap hm = new HashMap();
    SQLiteDatabase mydatabase ;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_newsdisp);
        mydatabase = openOrCreateDatabase("Mandaranews",MODE_PRIVATE,null);
        mydatabase.execSQL("Create table if not exists allnews(title varchar,news varchar,lang varchar,catogary varchar,date int,image blob,heart int,oplike int,dislike int);");
        tv_news = findViewById(R.id.textView3);
        iv_news = findViewById(R.id.imageView);
        iv_love = findViewById(R.id.imageView2);
        iv_like = findViewById(R.id.imageView3);
        iv_dislike = findViewById(R.id.imageView4);
        tv_love = findViewById(R.id.textView5);
        tv_like = findViewById(R.id.textView4);
        tv_dislike = findViewById(R.id.textView6);
        tv_title = findViewById(R.id.textView7);
        byte[] bytes = getIntent().getExtras().getByteArray("Img");
        iv_news.setImageBitmap(BitmapFactory.decodeByteArray(bytes,0,bytes.length));
        tv_love.setText(getIntent().getExtras().getString("Love"));
        tv_like.setText(getIntent().getExtras().getString("Like"));
        tv_dislike.setText(getIntent().getExtras().getString("Dislike"));
        tv_news.setText(getIntent().getExtras().getString("Value"));
        tv_news.setMovementMethod(new ScrollingMovementMethod());
        title = getIntent().getExtras().getString("Title");
        tv_title.setText(title);
        Cursor cr =mydatabase.rawQuery("Select * from allnews where title = '"+title+"';",null);
        cr.moveToFirst();
        heart_flag = cr.getInt(6);
        dislike_flag = cr.getInt(8);
        like_flag = 0;
        myRef = database.getReference(title);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull  DataSnapshot snapshot) {
                love_val = (long) snapshot.child("love").getValue();
                like_val = (long) snapshot.child("like").getValue();
                dislike_val = (long) snapshot.child("dislike").getValue();
                tv_love.setText(String.valueOf(love_val));
                tv_like.setText(String.valueOf(like_val));
                tv_dislike.setText(String.valueOf(dislike_val));
                if(like_flag == 0)
                {
                    like_flag++;
                    like_val++;
                    hm.put("like",like_val);
                    myRef.updateChildren(hm).addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {

                        }
                    });
                }
                

            }

            @Override
            public void onCancelled(@NonNull  DatabaseError error) {

            }
        });

        iv_love.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkupdate(2)==0)
                {
                    return;
                }
                hm.put("love",love_val);
                myRef.updateChildren(hm).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {

                    }
                });
            }

        });
        iv_dislike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkupdate(1)==0)
                {
                    return;
                }
                hm.put("dislike",dislike_val);
                myRef.updateChildren(hm).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {

                    }
                });
            }
        });
    }
    public int checkupdate(int a)
    {
        switch(a)
        {
            case 0:
                if(like_flag ==0)
                {
                    Removelikeheardislike(like_flag,dislike_flag,heart_flag);
                    like_flag++;
                    like_val++;
                    updatelikeheardislike(like_flag,dislike_flag,heart_flag);
                    return 1;
                }
                else
                {
                    return 0;
                }

            case 1:
                if(dislike_flag ==0)
                {
                    Removelikeheardislike(like_flag,dislike_flag,heart_flag);
                    dislike_val++;
                    dislike_flag++;
                    updatelikeheardislike(like_flag,dislike_flag,heart_flag);
                    return 1;
                }
                else
                {
                    return 0;
                }

            case 2:
                if(heart_flag ==0)
                {
                    Removelikeheardislike(like_flag,dislike_flag,heart_flag);
                    love_val++;
                    heart_flag++;
                    updatelikeheardislike(like_flag,dislike_flag,heart_flag);
                    return 1;
                }
                else
                {
                    return 0;
                }



        }
        return 0;
    }
    public void Removelikeheardislike(int lk,int dislk,int heart)
    {
        if(lk ==1)
        {


        }
        if(dislk ==1)
        {
            dislike_val--;
            dislike_flag=0;
            hm.put("dislike",dislike_val);
            myRef.updateChildren(hm).addOnSuccessListener(new OnSuccessListener() {
                @Override
                public void onSuccess(Object o) {

                }
            });
        }
        if(heart ==1)
        {
            love_val--;
            heart_flag=0;
            hm.put("love",love_val);
            myRef.updateChildren(hm).addOnSuccessListener(new OnSuccessListener() {
                @Override
                public void onSuccess(Object o) {

                }
            });
        }

    }
    public void updatelikeheardislike(int lk,int dislk,int heart)
    {
        ContentValues cval = new ContentValues();
        cval.put("heart",heart);
        cval.put("oplike",lk);
        cval.put("dislike",dislk);
        mydatabase.update("allnews",cval,"title =?",new String[]{title});
    }
}