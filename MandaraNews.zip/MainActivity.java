package com.nag.mandarnews;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class MainActivity extends AppCompatActivity {
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    StorageReference strf = FirebaseStorage.getInstance().getReference();
    DatabaseReference myRef = database.getReference();
    SQLiteDatabase mydatabase ;
    int news_count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int permission = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if(permission != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},123);
        }
        else
        {
            Intent a =new Intent(MainActivity.this,newstitle.class);
            startActivity(a);
            this.finish();
        }



    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull  int[] grantResults) {
        if(requestCode ==123)
        {
            if(grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED)
            {
                this.finish();
            }
            else
            {
                news_count=0;
                mydatabase = openOrCreateDatabase("Mandaranews",MODE_PRIVATE,null);
                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        mydatabase.execSQL("drop table if exists allnews");
                        mydatabase.execSQL("Create table allnews(title varchar,news varchar,lang varchar,catogary varchar,date varchar,image blob,heart int,oplike int,dislike int,latest datetime);");
                        for (DataSnapshot ds:snapshot.getChildren()) {
                            newsitem news_itm = ds.getValue(newsitem.class);
                            StorageReference stf = strf.child(news_itm.getTitle() + ".jpeg");
                            stf.getBytes(10 * 1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                                @Override
                                public void onSuccess(byte[] bytes) {
                                    Cursor cr =mydatabase.rawQuery("Select title from allnews where title = '"+news_itm.getTitle()+"';",null);
                                    cr.moveToFirst();
                                    ContentValues cval = new ContentValues();
                                    cval.put("title",news_itm.getTitle());
                                    cval.put("news",news_itm.getNews());
                                    cval.put("lang",news_itm.getLanguage());
                                    cval.put("catogary",news_itm.getCatogary());
                                    cval.put("date",news_itm.getDate());
                                    cval.put("image",bytes);
                                    String tmp = news_itm.getDate();
                                    tmp = tmp.replace("-","");
                                    tmp = tmp.replace(":","");
                                    tmp = tmp.replace(" ","");
                                    cval.put("latest",news_itm.getDate());
                                    if(cr.getCount() != 0 )
                                    {

                                        mydatabase.update("allnews",cval,"title =?",new String[]{news_itm.getTitle()});
                                        news_count++;
                                        if(news_count==4)
                                        {
                                            Intent a =new Intent(MainActivity.this,newstitle.class);
                                            startActivity(a);
                                            MainActivity.this.finish();
                                        }
                                    }
                                    else
                                    {
                                        cval.put("heart",0);
                                        cval.put("oplike",0);
                                        cval.put("dislike",0);
                                        mydatabase.insert("allnews",null,cval);
                                        news_count++;
                                        if(news_count==3)
                                        {
                                            Intent a =new Intent(MainActivity.this,newstitle.class);
                                            startActivity(a);
                                            MainActivity.this.finish();
                                        }

                                    }
                                }
                            });

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        }
        return;
    }
}