package com.nag.mandarnews;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class newstitle extends AppCompatActivity implements Myrecycleadapter.myreclerinterface{
    ListView lvw;
    RecyclerView lvwcat;
    Spinner langspin;
    Toolbar nagtoolbar;
    String cat_to_b_disp = "%",lang_to_b_disp = "%";
    ArrayList<String> arrlst = new ArrayList<>();
    ArrayList<String> Like_list = new ArrayList<>();
    ArrayList<String> DisLike_list = new ArrayList<>();
    ArrayList<String> Love_list = new ArrayList<>();
    ArrayList<String> news_list = new ArrayList<>();
    ArrayList<String> date_list = new ArrayList<>();
    ArrayList<String> lang_list = new ArrayList<>();
    ArrayList<String> catogary_list = new ArrayList<>();
    ArrayList<Bitmap> bitmap_list = new ArrayList<>();
    ArrayList<String> langlistspinner = new ArrayList<>();
    ArrayList<String> catlisttmp = new ArrayList<>();
    int flag =0;
    SQLiteDatabase mydatabase ;
    JobScheduler jb;
    newslayoutclass arraptr;
    Myrecycleadapter arrcatpter;
    ArrayAdapter<String> mylangadapter;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    StorageReference strf = FirebaseStorage.getInstance().getReference();
    DatabaseReference myRef = database.getReference();
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_newstitle);
        int permission = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if(permission != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(newstitle.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},123);
        }

        lvw = findViewById(R.id.listvw);
        lvwcat = findViewById(R.id.catlistview);
        nagtoolbar = findViewById(R.id.mandaratoolbarnag);
        setSupportActionBar(nagtoolbar);
        catlisttmp.add("General");
        arrcatpter = new Myrecycleadapter(catlisttmp,newstitle.this,this);
        lvwcat.setAdapter(arrcatpter);
        langspin = findViewById(R.id.langspin);
        langlistspinner.add("All");
        langlistspinner.add("Kannada");
        langlistspinner.add("Tulu");
        mylangadapter = new ArrayAdapter<String>(newstitle.this,R.layout.nags_tool_spin,langlistspinner);
        mylangadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        langspin.setAdapter(mylangadapter);
        LinearLayoutManager llm = new LinearLayoutManager(newstitle.this,LinearLayoutManager.HORIZONTAL,false);
        lvwcat.setLayoutManager(llm);
        lvwcat.setItemAnimator(new DefaultItemAnimator());
        jb=(JobScheduler)getSystemService(JOB_SCHEDULER_SERVICE);
        ComponentName cn = new ComponentName(this,newsupdatepolling.class);
        JobInfo hip = new JobInfo.Builder(101,cn)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(15*1000)
                .setRequiresCharging(false)
                .setPersisted(true)
                .build();
        jb.schedule(hip);
        mydatabase = openOrCreateDatabase("Mandaranews",MODE_PRIVATE,null);
        arraptr = new newslayoutclass(this, R.layout.listview_layout,arrlst,lang_list,catogary_list,bitmap_list,date_list);
        lvw.setAdapter(arraptr);
        AddCatList();
        AddLangList();
        updatenewsfromdatabase();

        langspin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lang_to_b_disp = langspin.getSelectedItem().toString();
                if(lang_to_b_disp == "All")
                {
                    lang_to_b_disp = "%";
                }
                updatenewsfromdatabase1();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull  DataSnapshot snapshot, @Nullable  String previousChildName) {

            }
            @Override
            public void onChildChanged(@NonNull  DataSnapshot snapshot, @Nullable  String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull  DataSnapshot snapshot) {
                try
                {
                    newsitem news_itm = snapshot.getValue(newsitem.class);
                    int pos = arrlst.indexOf(news_itm.getTitle());
                    arrlst.remove(pos);
                    news_list.remove(pos);
                    Like_list.remove(pos);
                    DisLike_list.remove(pos);
                    Love_list.remove(pos);
                    lang_list.remove(pos);
                    bitmap_list.remove(pos);
                    date_list.remove(pos);
                    catogary_list.remove(pos);
                    arraptr.notifyDataSetChanged();
                    mydatabase.delete("allnews","title =?",new String[]{news_itm.getTitle()});
                    flag =0;
                    updatenewsfromdatabase();

                }catch(Exception e)
                {
                    Toast.makeText(newstitle.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onChildMoved(@NonNull  DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                removedeleted(snapshot);
                mydatabase.execSQL("Create table if not exists allnews(title varchar,news varchar,lang varchar,catogary varchar,date varchar,image blob,heart int,oplike int,dislike int,latest bigint);");
                for (DataSnapshot ds:snapshot.getChildren()) {
                    newsitem news_itm = ds.getValue(newsitem.class);
                    StorageReference stf = strf.child(news_itm.getTitle() + ".jpeg");
                    stf.getBytes(10 * 1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Cursor cr =mydatabase.rawQuery("Select title from allnews where title = '"+news_itm.getTitle()+"';",null);
                            cr.moveToFirst();
                            ContentValues cval = new ContentValues();
                            cval.put("title",news_itm.getTitle());
                            cval.put("news",news_itm.getNews());
                            cval.put("lang",news_itm.getLanguage());
                            cval.put("catogary",news_itm.getCatogary());
                            cval.put("date",news_itm.getDate());
                            cval.put("image",bytes);
                            String tmp = news_itm.getDate();
                            tmp = tmp.replace("-","");
                            tmp = tmp.replace(":","");
                            tmp = tmp.replace(" ","");
                            cval.put("latest",news_itm.getDate());

                            if(cr.getCount() != 0 )
                            {

                                mydatabase.update("allnews",cval,"title =?",new String[]{news_itm.getTitle()});
                                flag =0;
                                updatenewsfromdatabase1();
                            }
                            else
                            {
                                cval.put("heart",0);
                                cval.put("oplike",0);
                                cval.put("dislike",0);
                                mydatabase.insert("allnews",null,cval);
                                ShowNotification();

                                flag =0;
                                updatenewsfromdatabase1();

                            }
                        }
                    });

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        lvw.setOnItemClickListener((parent, view, position, id) -> {
            Intent i  =new Intent(newstitle.this,newsdisp.class);
            i.putExtra("Value",news_list.get(position));
            i.putExtra("Love",Love_list.get(position));
            i.putExtra("Like",Like_list.get(position));
            i.putExtra("Dislike",DisLike_list.get(position));
            i.putExtra("Title",arrlst.get(position));
            ByteArrayOutputStream baot = new ByteArrayOutputStream();
            Bitmap bm =bitmap_list.get(position);
            bm.compress(Bitmap.CompressFormat.JPEG,100,baot);
            byte[] bytes =baot.toByteArray();
            i.putExtra("Img",bytes);
            startActivity(i);
        });
    }

    private void AddLangList() {
        Cursor cr2 =mydatabase.rawQuery("Select distinct lang from allnews ",null);
        cr2.moveToFirst();
        if(cr2.getCount() > 0) {
            langlistspinner.clear();
            langlistspinner.add("All");
            while(!cr2.isAfterLast())
            {

                langlistspinner.add(cr2.getString(0));
                cr2.moveToNext();
            }
            mylangadapter.notifyDataSetChanged();
        }
    }
    private void AddCatList() {
        Cursor cr2 =mydatabase.rawQuery("Select distinct catogary from allnews ",null);
        cr2.moveToFirst();
        if(cr2.getCount() > 0) {
            catlisttmp.clear();
            catlisttmp.add("All");
            while(!cr2.isAfterLast())
            {

                catlisttmp.add(cr2.getString(0));
                cr2.moveToNext();
            }
            arrcatpter.notifyDataSetChanged();
        }
    }

    private void removedeleted(DataSnapshot snapshot)
    {
        mydatabase.execSQL("Create table if not exists allnews(title varchar,news varchar,lang varchar,catogary varchar,date int,image blob,heart int,oplike int,dislike int,latest bigint);");
        Cursor cr2 =mydatabase.rawQuery("Select title from allnews ",null);
        cr2.moveToFirst();
        if(cr2.getCount() > 0) {
            while (!cr2.isAfterLast())
            {
                Cursor cr3 = mydatabase.rawQuery("Select * from allnews where title = '" + cr2.getString(0) + "';", null);
                cr3.moveToFirst();
                if(!snapshot.hasChild(cr3.getString(0)))
                {
                    int pos = arrlst.indexOf(cr3.getString(0));
                    arrlst.remove(pos);
                    news_list.remove(pos);
                    Like_list.remove(pos);
                    DisLike_list.remove(pos);
                    Love_list.remove(pos);
                    lang_list.remove(pos);
                    bitmap_list.remove(pos);
                    date_list.remove(pos);
                    catogary_list.remove(pos);
                    arraptr.notifyDataSetChanged();
                    mydatabase.delete("allnews","title =?",new String[]{cr3.getString(0)});
                }
                cr3.close();
                cr2.moveToNext();
            }

        }
        cr2.close();

    }


    private void updatenewsfromdatabase() {
        if(flag==0)
        {
            flag =1;
            arrlst.clear();
            news_list.clear();
            Like_list.clear();
            DisLike_list.clear();
            Love_list.clear();
            lang_list.clear();
            bitmap_list.clear();
            date_list.clear();
            catogary_list.clear();
            mydatabase.execSQL("Create table if not exists allnews(title varchar,news varchar,lang varchar,catogary varchar,date int,image blob,heart int,oplike int,dislike int,latest bigint);");
            Cursor cr =mydatabase.rawQuery("Select title from allnews order by latest desc",null);
            cr.moveToFirst();
            if(cr.getCount() > 0)
            {
                while(!cr.isAfterLast())
                {
                    Cursor cr1 =mydatabase.rawQuery("Select * from allnews where title = '"+cr.getString(0)+"';",null);
                    cr1.moveToFirst();
                    arrlst.add(cr1.getString(0));
                    news_list.add(cr1.getString(1));
                    Like_list.add(String.valueOf(cr1.getInt(7)));
                    DisLike_list.add(String.valueOf(cr1.getInt(8)));
                    Love_list.add(String.valueOf(cr1.getInt(6)));
                    lang_list.add(cr1.getString(2));
                    catogary_list.add(cr1.getString(3));
                    date_list.add(cr1.getString(4));
                    byte[] bts= cr1.getBlob(5);
                    Bitmap bmp = BitmapFactory.decodeByteArray(bts,0,bts.length);
                    bitmap_list.add(bmp);
                    arraptr.notifyDataSetChanged();
                    cr.moveToNext();
                }

            }

        }

    }


    private void updatenewsfromdatabase1() {

            flag =1;
            arrlst.clear();
            news_list.clear();
            Like_list.clear();
            DisLike_list.clear();
            Love_list.clear();
            lang_list.clear();
            bitmap_list.clear();
            date_list.clear();
            catogary_list.clear();
            mydatabase.execSQL("Create table if not exists allnews(title varchar,news varchar,lang varchar,catogary varchar,date int,image blob,heart int,oplike int,dislike int,latest bigint);");
            Cursor cr =mydatabase.rawQuery("Select title from allnews where lang like ? and catogary like ? order by latest desc",new String[]{lang_to_b_disp , cat_to_b_disp});
            cr.moveToFirst();
            if(cr.getCount() > 0)
            {
                while(!cr.isAfterLast())
                {
                    Cursor cr1 =mydatabase.rawQuery("Select * from allnews where title = '"+cr.getString(0)+"';",null);
                    cr1.moveToFirst();
                    arrlst.add(cr1.getString(0));
                    news_list.add(cr1.getString(1));
                    Like_list.add(String.valueOf(cr1.getInt(7)));
                    DisLike_list.add(String.valueOf(cr1.getInt(8)));
                    Love_list.add(String.valueOf(cr1.getInt(6)));
                    lang_list.add(cr1.getString(2));
                    catogary_list.add(cr1.getString(3));
                    date_list.add(cr1.getString(4));
                    byte[] bts= cr1.getBlob(5);
                    Bitmap bmp = BitmapFactory.decodeByteArray(bts,0,bts.length);
                    bitmap_list.add(bmp);
                    cr.moveToNext();
                }

            }
        AddCatList();
        arraptr.notifyDataSetChanged();
        AddLangList();
        mylangadapter.notifyDataSetChanged();

    }

    private void ShowNotification() {
        NotificationChannel channel = null;
        NotificationManager nM = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channel = new NotificationChannel("mandaranotify","Mandaranewschannel", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("To send alaram");
            nM.createNotificationChannel(channel);
        }

        NotificationCompat.Builder mB =(NotificationCompat.Builder) new NotificationCompat.Builder(getApplicationContext(),"mandaranotify")
                .setContentTitle("Mandara News")
                .setContentText("New News Updated")
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.meaage_icon);
        Intent intent = new Intent(getApplicationContext(),newstitle.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent=  PendingIntent.getActivity(getApplicationContext(),0,intent,0);
        mB.setContentIntent(pendingIntent);
        nM.notify(0,mB.build());

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull  int[] grantResults) {
        if(requestCode ==123)
        {
            if(grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED)
            {
                this.finish();
            }
        }
        return;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.tootbar_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.About:
                Intent i  = new Intent(newstitle.this,AboutUs.class);
                startActivity(i);
                break;
            case R.id.contactus:
                Intent em = new Intent(Intent.ACTION_SEND);
                em.setData(Uri.parse("email"));
                String[] s = {"aryavarshasoft@gmail.com"};
                em.putExtra(Intent.EXTRA_EMAIL,s);
                em.setType("text/plain");
                Intent chooser = Intent.createChooser(em,"Launch Email");
                startActivity(chooser);
                break;
        }

        return true;
    }

    @Override
    public void onMyclick(int position) {
        cat_to_b_disp = "%"+catlisttmp.get(position);
        if(catlisttmp.get(position) == "All" )
        {
            cat_to_b_disp = "%";
        }
        updatenewsfromdatabase1();
        arrcatpter.setRaw_index(position);
        arrcatpter.notifyDataSetChanged();
    }
}