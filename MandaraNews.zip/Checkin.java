package com.nag.mandarnews;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class Checkin extends AppCompatActivity {
    EditText et_phone;
    EditText et_otp;
    String Back_otp,verify_Id;
    Button send_otp;
    Button verify_otp;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkin);
        et_phone = findViewById(R.id.editTextPhone);
        et_otp = findViewById(R.id.editTextPhone2);
        send_otp = findViewById(R.id.button2);
        verify_otp = findViewById(R.id.button4);
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                Toast.makeText(Checkin.this, "Verification sucess", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onVerificationFailed(@NonNull  FirebaseException e) {
                Toast.makeText(Checkin.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCodeSent(@NonNull String bcode, @NonNull  PhoneAuthProvider.ForceResendingToken forceResendingToken) {

                Back_otp = bcode;
            }
        };
        send_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PhoneAuthOptions options =  PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance())
                        .setPhoneNumber("+91"+et_phone.getText().toString())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(Checkin.this)
                        .setCallbacks(mCallbacks)
                        .build();
                PhoneAuthProvider.verifyPhoneNumber(options);
            }
        });

        verify_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PhoneAuthCredential cd = PhoneAuthProvider.getCredential(Back_otp,et_otp.getText().toString());
                FirebaseAuth.getInstance().signInWithCredential(cd)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull  Task<AuthResult> task) {
                                if(task.isSuccessful())
                                {
                                    Intent a =new Intent(Checkin.this,newstitle.class);
                                    startActivity(a);

                                }else
                                {
                                    Toast.makeText(Checkin.this, "Log in failed", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });
            }
        });
    }
}