package com.nag.mandarnews;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nag.mandarnews.newsitem;

public class newsupdatepolling extends JobService {
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();
    Boolean new_news_found =false;

    StorageReference strf = FirebaseStorage.getInstance().getReference();
    @Override
    public boolean onStartJob(JobParameters params) {
        SQLiteDatabase mydatabase = openOrCreateDatabase("Mandaranews",MODE_PRIVATE,null);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull  DataSnapshot snapshot) {
                mydatabase.execSQL("Create table if not exists allnews(title varchar,news varchar,lang varchar,catogary varchar,date int,image blob,heart int,oplike int,dislike int);");
                for (DataSnapshot ds:snapshot.getChildren()
                     ) {
                    newsitem news_itm = ds.getValue(newsitem.class);
                    StorageReference stf = strf.child(news_itm.getTitle() + ".jpeg");
                    stf.getBytes(10 * 1024 * 1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Cursor cr =mydatabase.rawQuery("Select title from allnews where title = '"+news_itm.getTitle()+"';",null);
                            cr.moveToFirst();
                            ContentValues cval = new ContentValues();
                            cval.put("title",news_itm.getTitle());
                            cval.put("news",news_itm.getNews());
                            cval.put("lang",news_itm.getLanguage());
                            cval.put("catogary",news_itm.getCatogary());
                            cval.put("date",news_itm.getDate());
                            cval.put("image",bytes);
                            if(cr.getCount() == 0)
                            {
                                mydatabase.insert("allnews",null,cval);
                                ShowNotification();
                            }
                            else
                            {
                                cval.put("heart",0);
                                cval.put("oplike",0);
                                cval.put("dislike",0);
                                mydatabase.update("allnews",cval,"title =?",new String[]{news_itm.getTitle()});
                            }
                        }
                    });

                }


            }

            @Override
            public void onCancelled(@NonNull  DatabaseError error) {

            }
        });
        return true;
    }

    private void ShowNotification() {
        NotificationChannel channel = null;
        NotificationManager nM = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel("mandaranotify","Mandaranewschannel", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("To send alaram");
            nM.createNotificationChannel(channel);
        }

        NotificationCompat.Builder mB =(NotificationCompat.Builder) new NotificationCompat.Builder(getApplicationContext(),"mandaranotify")
                .setContentTitle("Mandara News")
                .setContentText("New News Updated")
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.meaage_icon);
        Intent intent = new Intent(getApplicationContext(),newstitle.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent=  PendingIntent.getActivity(getApplicationContext(),0,intent,0);
        mB.setContentIntent(pendingIntent);
        nM.notify(0,mB.build());
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}
