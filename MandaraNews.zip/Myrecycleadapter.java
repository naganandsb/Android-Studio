package com.nag.mandarnews;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Myrecycleadapter extends RecyclerView.Adapter<Myrecycleadapter.ViewHolder> {


    ArrayList<String> nagString;
    Context context;
    int raw_index =0;

    public int getRaw_index() {
        return raw_index;
    }

    public void setRaw_index(int raw_index) {
        this.raw_index = raw_index;
    }

    myreclerinterface myonclicklistner;
    public Myrecycleadapter() {
    }

    public Myrecycleadapter(ArrayList<String> nagString, Context context,myreclerinterface myonclicklistner) {
        this.nagString = nagString;
        this.context = context;
        this.myonclicklistner =myonclicklistner;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v  = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapterrecycle,parent,false);
        return new ViewHolder(v,myonclicklistner);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.textView.setText(nagString.get(position));

        if(position == raw_index)
        {
            holder.llv.setBackgroundColor(Color.parseColor("#70444444"));
        }
        else
        {
            holder.llv.setBackgroundColor(Color.parseColor("#000000"));
        }
    }

    @Override
    public int getItemCount() {
        return nagString.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textView;
        LinearLayout llv;
        myreclerinterface myrei;
        public ViewHolder(@NonNull View itemView,myreclerinterface myrei) {
            super(itemView);

            textView = itemView.findViewById(R.id.adptertextviewid);
            llv =  itemView.findViewById(R.id.nagrecycleadapter);
            this.myrei =myrei;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            myrei.onMyclick(getAdapterPosition());
        }
    }

    public interface myreclerinterface
    {
        void onMyclick(int position);

    }

}
