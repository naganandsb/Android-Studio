package com.nag.mandarnews;

public class newsitem {
  private String Title;
  private String news;
  private int like;
  private int dislike;
  private int love;
  private String date;
  private String language;
  private String catogary;

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public String getLanguage() {
    return language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }

  public String getCatogary() {
    return catogary;
  }

  public void setCatogary(String catogary) {
    this.catogary = catogary;
  }

  public int getLike() {
    return like;
  }

  public void setLike(int like) {
    this.like = like;
  }

  public int getDislike() {
    return dislike;
  }

  public void setDislike(int dislike) {
    this.dislike = dislike;
  }

  public int getLove() {
    return love;
  }

  public void setLove(int love) {
    this.love = love;
  }

  public newsitem(String title, String news, int like , int dislike, int love,String date,String language,String catogary) {
    Title = title;
    this.news = news;
    this.like = like;
    this.dislike =dislike;
    this.love = love;
    this.date = date;
    this.language = language;
    this.catogary = catogary;

  }

  public newsitem() {
  }

  public String getTitle() {
    return Title;
  }

  public void setTitle(String title) {
    Title = title;
  }

  public String getNews() {
    return news;
  }

  public void setNews(String news) {
    this.news = news;
  }
}
