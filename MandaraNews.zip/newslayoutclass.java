package com.nag.mandarnews;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class newslayoutclass extends ArrayAdapter {
  private ArrayList<String> lang;
  private ArrayList<String> cat;
  private ArrayList<String> title;
  private ArrayList<String> date;
  ArrayList<Bitmap> bitmap_list;
  public newslayoutclass(@NonNull Context context, int resource, @NonNull ArrayList<String> titles,ArrayList<String> lang,ArrayList<String> cat,ArrayList<Bitmap> bitmap_list,ArrayList<String> date) {
    super(context, resource, titles);
    this.date = date;
    this.cat = cat;
    this.lang =lang;
    this.title =titles;
    this.bitmap_list = bitmap_list;
  }

  @NonNull
  @Override
  public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
    LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View view = inflater.inflate(R.layout.listview_layout,parent,false);

    TextView tv1 = view.findViewById(R.id.tv_title);
    TextView tv2 = view.findViewById(R.id.tv_lang);
    TextView tv3 = view.findViewById(R.id.tv_cat);
    ImageView iv = view.findViewById(R.id.imv1);
    try{
      tv1.setText(title.get(position));
      tv2.setText(date.get(position));
      tv3.setText(cat.get(position)+"-"+lang.get(position));
      Bitmap bmpwtotscale = bitmap_list.get(position);
      bmpwtotscale = Bitmap.createScaledBitmap(bmpwtotscale,373,202,true);
      iv.setImageBitmap(bmpwtotscale);
    }catch(Exception e)
    {

    }


    return view;
  }
}
