package com.nag.mandarnews;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class AboutUs extends AppCompatActivity {
    LinearLayout lnlt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        lnlt =findViewById(R.id.naglt);
    }
}