package com.nag.medicalaryavarsha;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.Console;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Global Variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    private static final int nagsallrequest = 13;
    static final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    ImageButton img1,img2,img3,img4,img5,img6;
    BluetoothAdapter nagBluetoothadapter;
    BluetoothSocket nagBtSocket;
    InputStream getmsg=null;
    String readmsg="a";
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Global Variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ OnCreate~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int perchk = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.BLUETOOTH);
        nagBluetoothadapter = BluetoothAdapter.getDefaultAdapter();
        if(perchk  == PackageManager.PERMISSION_GRANTED)
        {
            if(!nagBluetoothadapter.isEnabled())
            {
                nagBluetoothadapter.enable();
            }
        }
        else
        {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.BLUETOOTH,Manifest.permission.BLUETOOTH_ADMIN},nagsallrequest);
        }
    }
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ OnCreate~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ App permission~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case nagsallrequest:
            {
                if(grantResults.length > 0 && grantResults[0]== PackageManager.PERMISSION_GRANTED)
                {
                    if(!nagBluetoothadapter.isEnabled())
                    {
                        nagBluetoothadapter.enable();
                    }
                }
            }
        }
    }
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ App Permission~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ User buttons~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void connect_bt(View v)
    {
        if(!nagBluetoothadapter.isEnabled())
        {
            nagBluetoothadapter.enable();

        }
        String tobesearch = "HC-05";
        Set<BluetoothDevice> nagsbtdevices = nagBluetoothadapter.getBondedDevices();
        for(BluetoothDevice btsingle : nagsbtdevices)
        {
            if(tobesearch.matches(btsingle.getName()))
            {
                int cnter = 0;
                do{
                    try {
                        nagBtSocket = btsingle.createRfcommSocketToServiceRecord(mUUID);
                        nagBtSocket.connect();


                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                    cnter++;
                }while (!nagBtSocket.isConnected() && cnter < 5);
            }
        }
        if(!nagBtSocket.isConnected())
        {
            return;
        }
        Toast.makeText(this, "BlueTooth Connected", Toast.LENGTH_SHORT).show();
    }

    public void ECG_bt(View v)
    {
        if(!nagBtSocket.isConnected())
        {
            return;
        }
        transmit("1");
        receive();
        Bitmap bm = BitmapFactory.decodeResource(getResources(),R.mipmap.ecg_foreground);
        //Toast.makeText(this, readmsg, Toast.LENGTH_SHORT).show();
        Intent int_new = new Intent(this,  heartbeat.class);
        int_new.putExtra("name","ECG Window");
        int_new.putExtra("startValue",readmsg);
        //int_new.putExtra("activity", (Serializable) this);
        int_new.putExtra("maxValue",100);
        int_new.putExtra("minValue",60);
        int_new.putExtra("message_id","1");
        int_new.putExtra("bitmap", (Parcelable)bm );
        this.startActivity(int_new);


    }

    public void Temparature_bt(View v)
    {
        if(!nagBtSocket.isConnected())
        {
            return;
        }
        transmit("2");
        receive();
        Bitmap bm = BitmapFactory.decodeResource(getResources(),R.mipmap.thermometer_foreground);
        //Toast.makeText(this, readmsg, Toast.LENGTH_SHORT).show();
        Intent int_new = new Intent(this,  heartbeat.class);
        int_new.putExtra("name","Temperature Window");
        int_new.putExtra("startValue",readmsg);
        //int_new.putExtra("activity", (Serializable) this);
        int_new.putExtra("maxValue",100);
        int_new.putExtra("minValue",60);
        int_new.putExtra("message_id","2");
        int_new.putExtra("bitmap", (Parcelable)bm );
        this.startActivity(int_new);
    }

    public void sugar_bt(View v)
    {
        if(!nagBtSocket.isConnected())
        {
            return;
        }
        transmit("3");
        receive();
        Bitmap bm = BitmapFactory.decodeResource(getResources(),R.mipmap.glucometer_foreground);
        //Toast.makeText(this, readmsg, Toast.LENGTH_SHORT).show();
        Intent int_new = new Intent(this,  heartbeat.class);
        int_new.putExtra("name","Gluecometer Window");
        int_new.putExtra("startValue",readmsg);
        //int_new.putExtra("activity", (Serializable) this);
        int_new.putExtra("maxValue",100);
        int_new.putExtra("minValue",60);
        int_new.putExtra("message_id","3");
        int_new.putExtra("bitmap", (Parcelable)bm );
        this.startActivity(int_new);
    }

    public void heartbeat_bt(View v)
    {
        if(!nagBtSocket.isConnected())
        {
            return;
        }
        transmit("4");
        receive();
        Bitmap bm = BitmapFactory.decodeResource(getResources(),R.mipmap.beartbeat_foreground);
        //Toast.makeText(this, readmsg, Toast.LENGTH_SHORT).show();
        Intent int_new = new Intent(this,  heartbeat.class);
        int_new.putExtra("name","Heart Beat Window");
        int_new.putExtra("startValue",readmsg);
        //int_new.putExtra("activity", (Serializable) this);
        int_new.putExtra("maxValue",100);
        int_new.putExtra("minValue",60);
        int_new.putExtra("message_id","4");
        int_new.putExtra("bitmap", (Parcelable)bm );
        this.startActivity(int_new);
    }

    public void bloodpressure_bt(View v)
    {
        if(!nagBtSocket.isConnected())
        {
            return;
        }
        transmit("5");
        receive();
        Bitmap bm = BitmapFactory.decodeResource(getResources(),R.mipmap.bp_foreground);
        //Toast.makeText(this, readmsg, Toast.LENGTH_SHORT).show();
        Intent int_new = new Intent(this,  heartbeat.class);
        int_new.putExtra("name","Blood Pressure Window");
        int_new.putExtra("startValue",readmsg);
        //int_new.putExtra("activity", (Serializable) this);
        int_new.putExtra("maxValue",100);
        int_new.putExtra("minValue",60);
        int_new.putExtra("message_id","5");
        int_new.putExtra("bitmap", (Parcelable)bm );
        this.startActivity(int_new);
    }
    public static void getnagsinstance()
    {

    }
    public void reserved_bt(View v)
    {
        if(!nagBtSocket.isConnected())
        {
            return;
        }
        transmit("6");
        receive();
        Bitmap bm = BitmapFactory.decodeResource(getResources(),R.mipmap.ecg_foreground);
        //Toast.makeText(this, readmsg, Toast.LENGTH_SHORT).show();
        Intent int_new = new Intent(this,  heartbeat.class);
        int_new.putExtra("name","Reserved Window");
        int_new.putExtra("startValue",readmsg);
        //int_new.putExtra("activity", (Serializable) this);
        int_new.putExtra("maxValue",100);
        int_new.putExtra("minValue",60);
        int_new.putExtra("message_id","6");
        int_new.putExtra("bitmap", (Parcelable)bm );
        this.startActivity(int_new);
    }

    public void disconnect_bt(View v)
    {
        try {
            nagBtSocket.close();
            nagBluetoothadapter.disable();
            Toast.makeText(this, "BlueTooth Disconnected", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ User Buttons~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Transmit function~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void transmit(String msg)
    {
        try {
            if(!nagBtSocket.isConnected())
            {
                return;
            }
            OutputStream outputStream = nagBtSocket.getOutputStream();
            outputStream.write(msg.getBytes());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Transmit function~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Receive function~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public void receive()
    {
        int nagsbytsavailable=0;
        try {
            if(!nagBtSocket.isConnected())
            {
                return;
            }
            getmsg = nagBtSocket.getInputStream();
            SystemClock.sleep(500);
            while((nagsbytsavailable = getmsg.available())<1 );
            if(nagsbytsavailable > 0)
            {
                byte[] nagbytes = new byte[nagsbytsavailable];
                getmsg.read(nagbytes);
                readmsg ="";
                for(int i=0; i < nagsbytsavailable;i++)
                {
                    readmsg += (char)nagbytes[i];
                }
            }
            else
            {
                return;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Receive function~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
}