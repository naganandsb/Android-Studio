package com.nag.medicalaryavarsha;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class heartbeat extends AppCompatActivity {
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Global Variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    public MainActivity maincontext;
    public int  minValue;
    public int maxValue;
    public String name;
    public Bitmap btimage;
    public String startValue;
    public String message_id;

    TextView Header_tv,Value_tv;
    ImageView icon_iv;
    ConstraintLayout cl;
    Button update_Bt;
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Global Variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heartbeat);

        Header_tv = findViewById(R.id.textView9);
        Value_tv = findViewById(R.id.textView10);
        icon_iv  = findViewById(R.id.imageView9);
        cl = findViewById(R.id.cl1);
        update_Bt = findViewById(R.id.button);

        //maincontext = (MainActivity) getIntent().getExtras().getSerializable("activity");
        minValue  =getIntent().getExtras().getInt("minValue");
        maxValue =getIntent().getExtras().getInt("maxValue");
        name =getIntent().getExtras().getString("name");
       btimage =(Bitmap) getIntent().getExtras().getParcelable("bitmap");
        startValue =getIntent().getExtras().getString("startValue");
        message_id =getIntent().getExtras().getString("message_id");
        updatevariablevalues();
    }

    public void updatevariablevalues()
    {
        Header_tv.setText(name);
        Value_tv.setText(startValue);
        icon_iv.setImageBitmap(btimage);
        setColortopage();
    }
    public void setColortopage() {
        if(Integer.parseInt((String) Value_tv.getText())<= minValue) {
           cl.setBackgroundColor(Color.YELLOW);
            update_Bt.setBackgroundColor(Color.YELLOW);
        }
        else if(Integer.parseInt((String) Value_tv.getText())<= maxValue) {
            cl.setBackgroundColor(Color.GREEN);
            update_Bt.setBackgroundColor(Color.GREEN);
        }
        else {
            cl.setBackgroundColor(Color.RED);
            update_Bt.setBackgroundColor(Color.RED);
        }
    }
   

    public void update_bt(View v)
    {
        maincontext.transmit(message_id);
        Value_tv.setText((CharSequence) maincontext.getmsg);
    }
}