package com.example.enggadda;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@RequiresApi(api = Build.VERSION_CODES.P)
public class MainActivity extends AppCompatActivity {

   final public int PERMISSION_ALL=123;
    SensorManager smgr ;
    Sensor snr;
    TextView disp,A,B;
    int counter,aut=0;
    ConstraintLayout nag2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        disp = findViewById(R.id.disp);
        A = findViewById(R.id.A);
        B = findViewById(R.id.B);

        nag2 = findViewById(R.id.nag);

        smgr = (SensorManager)this.getSystemService(SENSOR_SERVICE);
        snr = smgr.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        smgr.registerListener(nag,snr,SensorManager.SENSOR_DELAY_NORMAL);

        if(PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.USE_BIOMETRIC)
        ){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.USE_BIOMETRIC},PERMISSION_ALL);
        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if(aut<=2)
        {
            aut++;

            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                //deprecated in API 26
                v.vibrate(100);
            }
        }
        else if(aut>4)
        {
            aut=0;
        }
        else
        {
            aut++;
        }
        return true;
    }


    SensorEventListener nag = new SensorEventListener()
    {
        @Override
        public void onAccuracyChanged(Sensor sensor , int accuracy)
        {

        }
        @Override
        public void onSensorChanged(SensorEvent event)
        {
            if(event.sensor.getType() == Sensor.TYPE_PROXIMITY)
            {
                if(event.values[0]==0 && aut<2)
                {

                    counter++;
                    if(counter==1)
                    {
                        question();
                    }
                    if(counter==2)
                    {
                        Answer();
                        counter=0;
                    }

                }
            }
        }

    };
    public void question()
    {
        Random a = new Random();
        int Ar = a.nextInt(100);
        int Br= a.nextInt(100);
        A.setText(String.valueOf(Ar));
        B.setText(String.valueOf(Br));
        disp.setText("?");
    }

    public void  Answer()
    {
        disp.setText(String.valueOf(Integer.parseInt(A.getText().toString())+Integer.parseInt(B.getText().toString())));
    }
}