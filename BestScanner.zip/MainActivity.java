package com.aryavarsha.bestscanner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.graphics.BitmapCompat;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.Toast;

import com.example.bestscanner.R;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageOptions;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GetName.getnameDialog {
    private static final int PERMISSION_ALL =123;
    String pictureImagePath ="";
    Uri snapuri;
    int imgcnt=0;
    boolean switch_type= false;
    String newname;
    File file_pdf;
    int pagenum=0;
    PdfDocument document;
    FileOutputStream fOut;
    Bitmap nag;
    Button camera,pdf,load;
    ImageView imgvw;
    ListView lstvw;

    ArrayList<bsclass> proj_name;

    Uri uri;

    String[] PERMISSIONS ={
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        camera =findViewById(R.id.camera);


        lstvw =findViewById(R.id.lstview);

        load = findViewById(R.id.load);

        pdf =findViewById(R.id.pdf);

        imgvw =findViewById(R.id.img);

        imgvw.setVisibility(View.INVISIBLE);
        camera.setVisibility(View.INVISIBLE);
        pdf.setVisibility(View.INVISIBLE);
        load.setVisibility(View.INVISIBLE);
        lstvw.setVisibility(View.VISIBLE);

        if(PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(getApplicationContext(), PERMISSIONS[0])+
                        ContextCompat.checkSelfPermission(getApplicationContext(), PERMISSIONS[1]+
                                ContextCompat.checkSelfPermission(getApplicationContext(), PERMISSIONS[2]))
        ){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{PERMISSIONS[0],PERMISSIONS[1],PERMISSIONS[2]},PERMISSION_ALL);
        }


        lstvw.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                imgvw.setImageResource(android.R.color.transparent);
                bsclass pp =proj_name.get(position);
                newname = pp.getProj_name();
                if("New".matches(newname) && position==0)
                {
                    newbt();
                }
                else
                {
                    getimgcnt("/sdcard/BestScanner/"+newname+"/");
                    pdf.setVisibility(View.VISIBLE);
                    camera.setVisibility(View.VISIBLE);
                    load.setVisibility(View.VISIBLE);
                    lstvw.setVisibility(View.INVISIBLE);
                    imgvw.setVisibility(View.VISIBLE);
                }
            }
        });

    }
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~onPermission~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case PERMISSION_ALL:
            {
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
                {
                    showprojects();
                }
            }
        }
    }

    //~~~~~~~~~~~~~~~~~~~~~~~Take Snap Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void takesnap(View v)
    {
        String filename ="nagbwstscan";
        File storagedirectory =getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        try {
            File imgfile = File.createTempFile(filename,".jpg",storagedirectory);
            pictureImagePath= imgfile.getAbsolutePath();

            Uri imguri =FileProvider.getUriForFile(MainActivity.this,"com.example.bestscanner.fileprovider",imgfile);
            snapuri = imguri;
            Intent cam =new Intent();
            cam.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT,imguri);
            startActivityForResult(cam,1);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//~~~~~~~~~~~~~~~~~~~~~~~Take Snap End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~Taking New name Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void ReturnTexts(String name_entered) {

        newname = name_entered;
        if(!newname.isEmpty())
        {
            pdf.setVisibility(View.VISIBLE);
            camera.setVisibility(View.VISIBLE);
            load.setVisibility(View.VISIBLE);
            lstvw.setVisibility(View.INVISIBLE);
            imgvw.setVisibility(View.VISIBLE);

        }
        imgcnt = 0;
    }
//~~~~~~~~~~~~~~~~~~~~~~~Taking New name End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~Pdf creat call start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void closepdf(View v) {

        file_pdf = new File("/sdcard/BestScanner/" + newname + "/", newname + ".pdf");
        try {
            file_pdf.createNewFile();
            imgcnt = 0;
            document = new PdfDocument();
            fOut = new FileOutputStream(file_pdf);
            int scaledX = 1056;//btX/3;
            int scaledY = 816; //btY/3;

            Paint paint = new Paint();
            while (true) {
                pagenum++;
                File f = new File("/sdcard/BestScanner/" + newname + "/", "Img" + String.valueOf(imgcnt) + ".jpg");
                if (!f.exists())
                    break;
                imgcnt++;
//            "Height:"+String.valueOf(btX)+" Width:"+String.valueOf(btY)
                nag = BitmapFactory.decodeStream(new FileInputStream(f));
//                nag = Bitmap.createScaledBitmap(nag, scaledY, scaledX, false);
                PdfDocument.PageInfo pageInfo = new
                        PdfDocument.PageInfo.Builder(scaledY, scaledX, pagenum).create();
                PdfDocument.Page page = document.startPage(pageInfo);
                Canvas canvas = page.getCanvas();
                int x = nag.getHeight();
                int y = nag.getWidth();
                canvas.drawBitmap(nag, new Rect(0, 0, y,x ), new Rect(0, 0, scaledY, scaledX), paint);
                document.finishPage(page);
                document.writeTo(fOut);
            }
            document.close();
            File del = new File("/sdcard/BestScanner/" + newname + "/", "temp.jpg");
            del.delete();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Toast toast=  Toast.makeText(this, "Pdf Created", Toast.LENGTH_SHORT);
        toast.show();

        pdf.setVisibility(View.INVISIBLE);
        camera.setVisibility(View.INVISIBLE);
        load.setVisibility(View.INVISIBLE);
        showprojects();
        lstvw.setVisibility(View.VISIBLE);
        imgvw.setVisibility(View.INVISIBLE);
    }
//~~~~~~~~~~~~~~~~~~~~~~~Pdf create call End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~Temp file write start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void tempimgfilewrite()
    {

        File dir = new File("/sdcard/BestScanner/"+newname+"/");
        if(!dir.exists())
            dir.mkdirs();
        File file = new File(dir, "temp.jpg");
        FileOutputStream fOut = null;
        try {
            fOut = new FileOutputStream(file);
            nag.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
            fOut.flush();
            fOut.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//~~~~~~~~~~~~~~~~~~~~~~~Temp file write End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~onActivity result start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1)
        {
            if(resultCode !=RESULT_OK)
                return;

            if(CropImage.isReadExternalStoragePermissionsRequired(this,Uri.parse(pictureImagePath)))
            {
                uri =snapuri;
                requestPermissions( new String [] {Manifest.permission.READ_EXTERNAL_STORAGE},0);
            }
            else
            {
                StartCrop(snapuri);
            }

        }

        if(requestCode==3)
        {
                if(resultCode !=RESULT_OK)
                    return;

            ClipData clipData = data.getClipData();
            if(clipData !=null)
            {
                for(int i=0;i<clipData.getItemCount();i++)
                {
                    Uri imguri = clipData.getItemAt(i).getUri();
                    if(CropImage.isReadExternalStoragePermissionsRequired(this,Uri.parse(pictureImagePath)))
                    {
                        uri =imguri;
                        requestPermissions( new String [] {Manifest.permission.READ_EXTERNAL_STORAGE},0);
                    }
                    else
                    {
                        StartCrop(imguri);
                    }
                }
            }
            else
            {
                Uri imguri = data.getData();
                if(CropImage.isReadExternalStoragePermissionsRequired(this,Uri.parse(pictureImagePath)))
                {
                    uri =imguri;
                    requestPermissions( new String [] {Manifest.permission.READ_EXTERNAL_STORAGE},0);
                }
                else
                {
                    StartCrop(imguri);
                }

            }

        }

        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if(resultCode == RESULT_OK) {
                try {
                    jpgcreat( getContentResolver().openInputStream(result.getUri()));

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }

        if(requestCode==10 && resultCode == RESULT_OK)
        {
            switch_type = data.getBooleanExtra("switchtype",false);
            Dispimage();
        }
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~onActivity result  Pdf End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Disp Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void Dispimage() {

        if(imgcnt==0)
            return;
        imgcnt--;
        File f=new File("/sdcard/BestScanner/"+newname+"/","Img"+String.valueOf(imgcnt)+".jpg");
        imgcnt++;
        if(!f.exists())
        {
            return;
        }
        try {
            nag = BitmapFactory.decodeStream(new FileInputStream(f));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return;
        }

        imgvw.setImageBitmap(nag);

    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Disp End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~jpgcreat Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void jpgcreat(InputStream getimg)
    {
        Bitmap temp = BitmapFactory.decodeStream(getimg);
        nag =temp;
        tempimgfilewrite();
        imgvw.setImageBitmap(temp);

        File dir = new File("/sdcard/BestScanner/"+newname+"/");
        if(!dir.exists())
            dir.mkdirs();
        File file = new File(dir, "Img" + String.valueOf(imgcnt) + ".jpg");
        FileOutputStream fOut = null;
        try {
            fOut = new FileOutputStream(file);
            temp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);

            imgcnt++;
            Intent filterintent= new Intent(this,FilterActivity.class);
            filterintent.putExtra("newname",newname);
            filterintent.putExtra("imgcnt",imgcnt);
            filterintent.putExtra("switchtype",switch_type);
            startActivityForResult(filterintent,10);
            fOut.flush();
            fOut.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~jpgcreat End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Crop Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void StartCrop(Uri path)
    {
        CropImage.activity(path)
                .setGuidelines(CropImageView.Guidelines.ON)
                .setMultiTouchEnabled(true)
                .start(this);
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Crop End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~newbt Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void newbt()
    {
        GetName getName = new GetName();
        getName.show(getSupportFragmentManager(),"GetName");
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~newbt End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~share Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public  void share(View v)
    {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        Uri screenshotUri = Uri.parse("/sdcard/BestScanner/"+newname+"/"+newname+".pdf");
        sharingIntent.setType("application/pdf");
        sharingIntent.putExtra(Intent.EXTRA_STREAM, screenshotUri);
        this.startActivityForResult(Intent.createChooser(sharingIntent, "Share using"),4);
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~share End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~getimgcnt Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void getimgcnt(String path)
    {
        imgcnt=0;
        while(true) {
            File test = new File(path, "Img" + String.valueOf(imgcnt) + ".jpg");
            if (!test.exists()) {
                break;
            }
            imgcnt++;
        }
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~getimgcnt End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~getinternalimg Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void getinternalimg(View v)
    {
        Intent imgintent = new Intent(Intent.ACTION_GET_CONTENT);
        imgintent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,"false");
        imgintent.setType("image/*");
        this.startActivityForResult(imgintent,3);
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~getinternalimg End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~showprojects Start~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    public void showprojects()
    {
        boolean share_flg = false;
        proj_name =new ArrayList<>();
        proj_name.clear();

        File dir = new File("/sdcard/BestScanner");
        if(dir.exists())
        {
            nag = ((BitmapDrawable) this.getResources().getDrawable(R.mipmap.newimg_foreground)).getBitmap();
            proj_name.add(new bsclass(nag,"New",false,false));
            File[] list = dir.listFiles();
            for (File sf: list) {
                if(!sf.isDirectory())
                {
                    continue;
                }
                share_flg = false;
                File f = new File(sf, "Img" + String.valueOf(0) + ".jpg");

                if(!f.exists())
                {
                    nag = ((BitmapDrawable) this.getResources().getDrawable(R.mipmap.emptyimg_foreground)).getBitmap();
                }
                else
                {
                    try {
                        nag = BitmapFactory.decodeStream(new FileInputStream(f));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

                String[] ssf= sf.getPath().split("/");
                File fpdf = new File(sf,ssf[ssf.length-1]+".pdf" );
                if(fpdf.exists())
                {
                    share_flg = true;
                }

                proj_name.add(new bsclass(nag,ssf[ssf.length-1],true,share_flg));

            }
        }
        BsListAdapter adapter =new BsListAdapter(this,
                android.R.layout.simple_list_item_1,proj_name);
        lstvw.setAdapter(adapter);

    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~showprojects End~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
