package com.aryavarsha.bestscanner;

import android.graphics.Bitmap;

public class bsclass {


    Bitmap bitmap;

    String proj_name;

    boolean dlt_flag;



    boolean share_flag;

    public bsclass(Bitmap bitmap, String proj_name , boolean dlt_flag,boolean share_flag) {
        this.bitmap = bitmap;
        this.proj_name = proj_name;
        this.dlt_flag = dlt_flag;
        this.share_flag = share_flag;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public String getProj_name() {
        return proj_name;
    }

    public boolean isDlt_flag() {
        return dlt_flag;
    }

    public boolean isShare_flag() {
        return share_flag;
    }
}
