package com.aryavarsha.bestscanner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import com.example.bestscanner.R;

public class GetName extends AppCompatDialogFragment {
    EditText et;
    getnameDialog getnameDialoglistner;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();

        View view = inflater.inflate(R.layout.activity_get_name,null);

        et = view.findViewById(R.id.editTextTextPersonName2);
        builder.setView(view).setTitle("Enter the Project name")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getnameDialoglistner.ReturnTexts("");
                    }
                })
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        getnameDialoglistner.ReturnTexts(et.getText().toString());
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            getnameDialoglistner =(getnameDialog) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()+"must impliment getnameDialog");
        }
    }

    public interface getnameDialog{
        void ReturnTexts(String name_entered);
    }

}