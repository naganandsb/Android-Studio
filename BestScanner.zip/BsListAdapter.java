package com.aryavarsha.bestscanner;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.bestscanner.R;

import java.io.File;
import java.util.List;
import java.util.zip.Inflater;

public class BsListAdapter extends ArrayAdapter<bsclass>{

    Context bscontext;
    int bsresource;
    List<bsclass> bslist;
    public BsListAdapter(@NonNull Context context, int resource, @NonNull List<bsclass> blist) {
        super(context, resource, blist);
        bscontext = context;
        bsresource= resource;
        bslist =blist;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater bsinflater = LayoutInflater.from(bscontext);
        View bsview = bsinflater.inflate(R.layout.bs_list_item,null);
        final TextView prj_namelst = bsview.findViewById(R.id.projectnamelst);
        ImageView btmaplst = bsview.findViewById(R.id.bitmaplst);

        final bsclass bsclasslst = bslist.get(position);

        Button bt_dlt = bsview.findViewById(R.id.bsdelete);

        Button bt_share = bsview.findViewById(R.id.bsshare);

        btmaplst.setImageBitmap(bsclasslst.getBitmap());

        prj_namelst.setText(bsclasslst.getProj_name());

        bt_dlt.setVisibility(bsclasslst.isDlt_flag()?View.VISIBLE:View.INVISIBLE);

        bt_share.setVisibility(bsclasslst.isShare_flag()?View.VISIBLE:View.INVISIBLE);

        bt_dlt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder adb = new AlertDialog.Builder(bscontext);
                adb.setTitle("Are you sure you want to delete?");
                adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String foldname = bsclasslst.getProj_name();
                        File f  = new File("/sdcard/BestScanner",foldname);
                        if(f.exists())
                        {
                            deleteRecursive(f);
                        }
                        bslist.remove(position);
                        notifyDataSetChanged();
                    }
                });
                adb.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog alrtd = adb.create();
                alrtd.show();
            }
        });

        bt_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String foldname = bsclasslst.getProj_name();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                Uri screenshotUri = Uri.parse("/sdcard/BestScanner/"+foldname+"/"+foldname+".pdf");
                sharingIntent.setType("application/pdf");
                sharingIntent.putExtra(Intent.EXTRA_STREAM, screenshotUri);
                bscontext.startActivities(new Intent[]{Intent.createChooser(sharingIntent, "Share using")});
            }
        });
        return bsview;
    }

    void deleteRecursive(File fileOrDirectory) {

        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                deleteRecursive(child);

        fileOrDirectory.delete();

    }


}
