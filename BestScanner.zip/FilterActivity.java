package com.aryavarsha.bestscanner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;

import com.example.bestscanner.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FilterActivity extends AppCompatActivity {

    Bitmap nag;
    String newname;
    ImageView imgvw;
    Switch swtch;
    int imgcnt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        swtch = findViewById(R.id.switch1);

        imgvw =findViewById(R.id.imageView);

        Intent gtintent = getIntent();

        newname = gtintent.getStringExtra("newname");


        imgcnt = gtintent.getIntExtra("imgcnt",1);

        Dispimage();

        swtch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                imagetype();
            }
        });

        swtch.setChecked(gtintent.getBooleanExtra("switchtype",false));
    }

    public void Dispimage() {

        File f=new File("/sdcard/BestScanner/"+newname+"/","temp.jpg");
        if(!f.exists())
        {
            return;
        }
        try {
            nag = BitmapFactory.decodeStream(new FileInputStream(f));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return;
        }

        imgvw.setImageBitmap(nag);

    }

    public void back(View v)
    {
        Intent intent = new Intent();
        intent.putExtra("switchtype",swtch.isChecked());
        setResult(RESULT_OK, intent);

        finish();
    }
    public void imagetype()
    {
        imgcnt--;
        File f=new File("/sdcard/BestScanner/"+newname+"/","temp.jpg");
        if(!f.exists())
        {
            return;
        }
        try {
            nag = BitmapFactory.decodeStream(new FileInputStream(f));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return;
        }

        if(swtch.isChecked())
            nag =toGrayscale(nag);
        imgvw.setImageBitmap(nag);

        File dir = new File("/sdcard/BestScanner/"+newname+"/");
        if(!dir.exists())
            dir.mkdirs();
        File file = new File(dir, "Img" + String.valueOf(imgcnt) + ".jpg");
        FileOutputStream fOut = null;
        try {
            fOut = new FileOutputStream(file);
            nag.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
            fOut.flush();
            fOut.close();
            imgcnt++;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Bitmap toGrayscale(Bitmap src){

        //Custom color matrix to convert to GrayScale
//        float[] matrix = new float[]{
//                0.3f, 0.59f, 0.11f, 0, 0,
//                0.3f, 0.59f, 0.11f, 0, 0,
//                0.3f, 0.59f, 0.11f, 0, 0,
//                0, 0, 0, 1, 0,};

        float[] matrix = new float[]{
                0.5f, 0.5f, 0.5f, 0, 1,
                0.5f, 0.5f, 0.5f, 0, 1,
                0.5f, 0.5f, 0.5f, 0, 1,
                0, 0, 0, 1, 1,};

        Bitmap dest = Bitmap.createBitmap(
                src.getWidth(),
                src.getHeight(),
                src.getConfig());

        Canvas canvas = new Canvas(dest);
        Paint paint = new Paint();
        ColorMatrixColorFilter filter = new ColorMatrixColorFilter(matrix);
        paint.setColorFilter(filter);
        canvas.drawBitmap(src, 0, 0, paint);

        return dest;
    }
}